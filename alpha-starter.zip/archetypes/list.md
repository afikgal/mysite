+++
# Content Identity
title = "{{ replace .File.ContentBaseName `-` ` ` | title }}"
description = ""

# Dates
date = "{{ .Date }}"
lastmod = ""

# Pagination
paginate = true

# Series
series = ""
weight = 0

# Publication Control
draft = false
layout = "list"

# Advanced SEO
seo_type = ""
seo_image = ""
twitter_username = ""
+++
