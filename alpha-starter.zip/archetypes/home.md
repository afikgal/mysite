+++
# Content Identity
title = "{{ replace .File.ContentBaseName `-` ` ` | title }}"
description = ""

# Dates
date = "{{ .Date }}"
lastmod = ""

# Publication Control
draft = false
layout = "home"

# Advanced SEO
seo_type = ""
seo_image = ""
twitter_username = ""
+++
