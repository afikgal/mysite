+++
title = "{{ replace .File.ContentBaseName `-` ` ` | title }}"
description = ""

date = "{{ .Date }}"
author = ""

draft = false

# Use a specific archetype with `--kind`
# More info at https://alpha.oxypteros.com/docs/content-creation/
+++
