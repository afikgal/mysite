+++
# Content Identity
title = "{{ replace .File.ContentBaseName `-` ` ` | title }}"
description = ""

# Dates
date = "{{ .Date }}"
lastmod = ""
show_date = false

# Publication Control
draft = false
layout = "utility"

# Advanced SEO
seo_type = ""
seo_image = ""
twitter_username = ""
+++
