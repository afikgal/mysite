+++
# Content Identity
title = "{{ replace .File.ContentBaseName `-` ` ` | title }}"
description = ""

# Authoring
author = ""
date = "{{ .Date }}"
lastmod = ""
license = ""

# Organization
categories = []
tags = []
## Series
series = ""
parts = ""
weight = 0

# Display
featured = false
recommended = false

# Publication Control
draft = false
layout = "page"

# Advanced SEO
seo_type = ""
seo_image = ""
twitter_username = ""
+++
